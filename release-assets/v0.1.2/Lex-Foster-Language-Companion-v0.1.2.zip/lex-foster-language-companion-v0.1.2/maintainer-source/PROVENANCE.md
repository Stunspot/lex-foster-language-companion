# Provenance

Current 0.1.2 reissue carries the accepted task-fit, evidence and package repairs under a distinct updateable identity. The original 0.1.1 authorship and qualification narrative below retains its original scope; operative teaching/translation content is unchanged from the accepted repair.

## Canonical sources retained outside this public repository

| Source | Custody | Use | Public release treatment |
|---|---|---|---|
| `Universal Language Tutor - Lex Foster T1 v1.2.txt` | Collaborative Dynamics source library | primary identity, broad linguistic education, adaptivity, motivation, cultural awareness | grown derivative authored for this product; canonical prompt text and original image are not copied |
| `Protocol Droid - C-3PO T3 v1.txt` | Collaborative Dynamics source library containing a third-party character persona | translation layers, meaning extraction, protocol, etiquette, register, diplomacy | consulted build-side only; character identity, likeness, and source text excluded |

The public practitioner is an original derivative centered on Lex Foster. It does not present, imitate, or distribute a third-party entertainment character.

## Publicly consulted foundations

- ACTFL Proficiency Guidelines 2024 public pages and official-use boundary
- Council of Europe CEFR Companion Volume public hub
- Lyster and Saito (2010) corrective-feedback meta-analysis
- Xu and Zeng (2023) corrective-feedback timing systematic review
- Multidimensional Quality Metrics public overview
- Mariana, Cox, and Melby (2015) MQM viability study

Links and product implications appear in `skills/lex-foster-language-companion/references/evidence-foundations.md`. Framework names remain the property of their respective organizations. This package is not endorsed by them and issues no official rating.

## Authored synthesis

All public runtime prompts, references, templates, schemas, scripts, demonstrations, and evaluations in version 0.1.1 were authored for this Augment under the governing map. Exact source and distribution parity is established by the release manifest and four-gate re-entry evidence, not by this narrative.

## 2026-10-06 maintenance derivative

The active v0.1.1 practitioner now preserves host identity and treats the original character biography as fictional ancestry. Canonical v0.1.0 and the original private seed remain unchanged. Current source repairs make task-fit stopping, inspectable progress and concrete teaching examples consistent with the accepted promise. No new official assessment, host or language-coverage authority is added.
